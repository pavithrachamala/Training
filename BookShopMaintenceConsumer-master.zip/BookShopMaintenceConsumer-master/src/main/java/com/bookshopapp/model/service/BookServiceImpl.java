package com.bookshopapp.model.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookshopapp.model.entities.Book;
import com.bookshopapp.model.repository.BookRepo;

@Service
@Transactional
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepo bookRepo;

	@Override
	public List<Book> getAllBooks() {
		return bookRepo.findAll();
	}

	
	/*
	 * @Override public Optional<Book> findBookByName(String Book) {
	 * 
	 * return bookRepo.findBookByName(Book); }
	 */

	/*
	 * @Override public List<Book> findBookByNameContaining(String Book) { // TODO
	 * Auto-generated method stub return bookRepo.findBookByNameContaining(Book);
	 * 
	 * }
	 */
	@Override
	public Optional<Book> findBookById(Long id) {
		// TODO Auto-generated method stub
		return bookRepo.findById(id);
	}


	@Override
	public Optional<Book> findBybookName(String bookName) {
		// TODO Auto-generated method stub
		return bookRepo.findBybookName(bookName);
	}

}
