package com.bookshopapp.model.service;

import java.util.List;
import java.util.Optional;

import com.bookshopapp.model.entities.Book;


public interface BookService {
	public List<Book>getAllBooks();
	public Optional<Book>findBookById(Long id);

	public Optional<Book> findBybookName(String bookName); 
	//List<Book>findBookByNameContaining(String Book);
	


}
